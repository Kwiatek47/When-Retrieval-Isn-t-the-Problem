# Wklejenie do oficjalnego szablonu ML4H 2026

Otwórz [Machine Learning for Health (ML4H) 2026 Template](https://www.overleaf.com/latex/templates/machine-learning-for-health-ml4h-2026-template/sqgwhtyswgcy) → Copy Project. **Nie** podmieniaj preambuły/sty szablonu na lokalny `article` z `paper/main.tex` — ten `.sty` jest tylko na Overleaf (brak CTAN/GitHub). Zostaw `\documentclass` i `\usepackage` z szablonu. W preambule dodaj `\yes/\no/\maybe/\uscore` (komentarz w `body-snippet.tex`). Wgraj: `sections/`, `figures/*.pdf`, `references.bib`. W `main.tex` szablonu wklej title/author (Anonymous), abstract, Keywords, Data and Code Availability + IRB oraz `\input{sections/...}` z `body-snippet.tex`. Skasuj przykład szablonu. Skompiluj, sprawdź **≤4 strony treści**, zostaw anonim. Po GPU (SC) zaktualizuj wiersz w `sections/05_results.tex` i wgraj ponownie.

Szczegóły i komendy GPU: `../ML4H-V1-PLAN.md`.
