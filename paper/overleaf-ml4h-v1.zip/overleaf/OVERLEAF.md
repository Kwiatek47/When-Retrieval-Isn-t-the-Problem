# Wklejenie do oficjalnego szablonu ML4H 2026 (krok po kroku)

Szablon 2026 jest **tylko na Overleaf** (brak publicznego CTAN/GitHub — nie vendoringujemy `.sty`).
Lokalny `paper/main.tex` (`article`) **nie** jest PDF-em do OpenReview.

Szablon: https://www.overleaf.com/latex/templates/machine-learning-for-health-ml4h-2026-template/sqgwhtyswgcy

## 1. Nowy projekt ze szablonu 2026

1. Otwórz link powyżej (rok **2026**, nie 2024/2025).
2. **Copy Project** / **Open as Template**.
3. W nowym projekcie zostaw **całą preambułę szablonu**: `\documentclass`, `\usepackage{...}`, pliki `.sty` / `.bst`.  
   **Nie** wgrywaj `paper/main.tex` jako zamiennika. **Nie** kopiuj lokalnego `article` preamble.

## 2. Wgraj pliki z tego folderu (`paper/overleaf/`)

Menu Overleaf → Upload (albo drag-and-drop). Zachowaj ścieżki:

| Lokalnie | W projekcie Overleaf |
|---|---|
| `sections/*.tex` | `sections/` (ten sam katalog) |
| `figures/*.pdf` | `figures/` (`auroc_forest.pdf`, `risk_coverage.pdf`, `stage_separated.pdf`) |
| `references.bib` | `references.bib` w katalogu głównym projektu |

Nie wgrywaj `OVERLEAF.md` ani `body-snippet.tex` jako `main.tex`.

## 3. Cztery makra w preambule szablonu

Tuż **przed** `\begin{document}` w `main.tex` szablonu wklej:

```latex
\newcommand{\yes}{\textsf{yes}}
\newcommand{\no}{\textsf{no}}
\newcommand{\maybe}{\textsf{maybe}}
\newcommand{\uscore}{$u$-score}
```

Jeśli szablon już definiuje któreś z nich — nie duplikuj.

## 4. Zamień ciało dokumentu

W `main.tex` szablonu:

1. Zostaw `\documentclass` + `\usepackage` + makra z kroku 3.
2. **Skasuj** przykładowy title/abstract/sekcje szablonu (lorem / demo).
3. Wklej **od `\title{...}` do `\bibliography{references}`** z `body-snippet.tex` (ten folder).
4. Author block zostaw **Anonymous** (jak w snippecie). Żadnych nazwisk, uczelni, URL-i repo.
5. Jeśli szablon wymaga tracku, ustaw **Findings** (nie Proceedings). Szukaj `\mlhtrack` / podobnego przełącznika w preambule — nie zgaduj sty, tylko użyj komendy z szablonu 2026.

## 5. Skompiluj i sprawdź limit

1. Compiler: pdfLaTeX (albo ten, który podaje szablon).
2. PDF musi mieć **≤4 strony treści** przed bibliografią. Refs mogą iść dalej.
3. Sprawdź: brak nazwisk, brak URL repo, Data and Code Availability + IRB zaraz po abstract, SC **nie** jest zmyślone (wiersz `pending`, dopóki nie ma JSON-a).

## 6. Po GPU (SC)

Gdy istnieje `reports/debate/sc_balanced90_ml4h_v1.json`:

```bash
.venv/bin/python scripts/agents/insert_sc_row.py
```

Potem wgraj ponownie `sections/05_results.tex` (i ewentualnie zaktualizowany `body-snippet.tex` / abstract, jeśli inserter ich nie rusza). **Nie** wpisuj liczby z głowy.

Komendy GPU: `../ML4H-V1-PLAN.md` oraz `scripts/agents/run_ml4h_v1_arms.sh`.
